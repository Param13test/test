describe('Login in to the OrangeHRM Application', () => {
    it('verify user is able to Login with valid credentials', () => {


        // Visit the web link
        cy.visit("https://opensource-demo.orangehrmlive.com")
        cy.title().should('eq', 'OrangeHRM')

        // Verify user is on login page
        cy.get("button[type='submit']").contains('Login')

        //  Verify user is able to login
        cy.get("input[name='username']").type('Admin')  
        cy.get("input[name='password']").type('admin123')
        cy.get("button[type='submit']").click()

        //  Click on PIM option from sidebar
        cy.get("a[href='/web/index.php/pim/viewPimModule']").click()

        // Verify user is on employee list page
        cy.url().should('include', 'pim/viewEmployeeList')

        // Verify Employee information section
        cy.get('.oxd-topbar-body-nav-tab.--visited').should('have.css', 'background-color', 'rgba(255, 123, 29, 0.1)')

        // Click on Add+  button
        cy.get('.orangehrm-header-container > .oxd-button').click()

        // Verify user is on addEmployee page
        cy.url().should('include', 'pim/addEmployee')
        cy.get('h6.orangehrm-main-title').contains('Add Employee')

        // Verify all the fields are visible and enable
        cy.get("input[name='firstName']").should('be.visible').and('be.enabled');   // First name field 
        cy.get("input[name='middleName']").should('be.visible').and('be.enabled');   // Middle name field 
        cy.get("input[name='lastName']").should('be.visible').and('be.enabled');   // Last name field 
        cy.get("div[class='oxd-input-group oxd-input-field-bottom-space'] div input[class='oxd-input oxd-input--active']").should('be.visible').and('be.enabled');  // Employee Id
        cy.get("button.oxd-button--ghost").should('be.visible').and('be.enabled');  // Cancel button
        cy.get("button[type='submit']").should('be.visible').and('be.enabled');  // Submit button

        //  Verify user is able to add profile image


        // Verify user is able to fill the fields
        cy.get("input[name='firstName']").type('Parminder1');   
        cy.get("input[name='middleName']").type('preet1');   
        cy.get("input[name='lastName']").type('Singh1') ;
        cy.get("div[class='oxd-input-group oxd-input-field-bottom-space'] div input[class='oxd-input oxd-input--active']").clear().type('131313');

        // Verify user is able to click on "Create Login Details" toggle button
        cy.get("span.--label-right").click();

        // Verify user is able to fill the fields under login details
        cy.get("div[class*='oxd-form-row']:nth-child(4) input[class='oxd-input oxd-input--active']").type('Param1') ;
        cy.get("div[class*='user-password-cell'] input").type('Qa@12345')
        cy.get("div[class*='oxd-grid-item oxd-grid-item--gutters']:nth-child(2) input[type*='password']").type('Qa@12345')
        
        // Verify user is able to Click on the save button
        cy.get("button[type='submit']").click();
       
        // Verify successfull message is showing
        cy.get('.oxd-toast-content--success').contains('Success').should('be.visible')

        // Logout from the application 
        cy.get(".oxd-userdropdown-tab").click()
        cy.xpath("//a[normalize-space()='Logout']").click()


        // Verify user is able to login with recently created employee

        

    })

})