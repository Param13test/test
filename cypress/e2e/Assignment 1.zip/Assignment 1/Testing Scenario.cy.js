describe('Login in to the OrangeHRM Application', () => {
    it('verify user is able to Login with valid credentials', () => {


        // Visit the web link
        cy.visit("https://opensource-demo.orangehrmlive.com")
        cy.title().should('eq', 'OrangeHRM')

        // Verify user is on login page
        cy.get("button[type='submit']").contains('Login')


        // Verify username field,  password field and login button should be visible and enabled
        cy.get("input[placeholder='username']").should('be.visible')
        cy.get("input[placeholder='password']").should('be.visible')
        cy.get("button[type='submit']").contains('Login')


        // Verify user is not able login with empty username  field and empty password field
        cy.get("button[type='submit']").click()
        cy.get(':nth-child(2) > .oxd-input-group > .oxd-text').should('be.visible');

        // Verify user is not able login with invalid username  field and valid password field
        cy.get("input[placeholder='username']").type('qweqwe')
        cy.get("input[placeholder='password']").type('admin123')
        cy.get("button[type='submit']").click()
        cy.get("div[role='alert']").should('be.visible')

        // Verify user is not able login with valid username  field and invalid password field
        cy.get("input[placeholder='username']").type('Admin')
        cy.get("input[placeholder='password']").type('adm11in123')
        cy.get("button[type='submit']").click()
        cy.get("div[role='alert']").should('be.visible')

        // Verify user is not able login with invalid username  field and invalid password field
        cy.get("input[placeholder='username']").type('Admin123')
        cy.get("input[placeholder='password']").type('adm11in123123')
        cy.get("button[type='submit']").click()
        cy.get("div[role='alert']").should('be.visible')

        // Verify forgot password link is visible
        cy.get('.orangehrm-login-forgot').should('be.visible')

        // erify forgot password functionaity is working
        cy.get('.orangehrm-login-forgot').click()
        cy.get("input[placeholder='username']").type('Admin')
        cy.get("button[type='submit']").click()

        cy.get("#app").contains('link sent successfully')
        cy.go(-2)


        // Verify Sidebar is showing with their options on dashboard page

        cy.get("input[placeholder='username']").type('Admin')
        cy.get("input[placeholder='password']").type('admin123')
        cy.get("button[type='submit']").click()

        cy.url().should('include', '/dashboard/index')
        cy.get('.oxd-sidepanel').should('be.visible')

        // Verify search field is working acc. to its functionality oon sidebar.

        cy.get("input[placeholder='Search']").type('PIM')
        cy.get('.oxd-main-menu-item').click()

        //  Verify user is able to navigate to each option od sidebar

        cy.get("a[href*='/admin/viewAdminModule']").click()  //admin side option
        
        cy.url().should('include', '/admin/viewSystemUsers')
       // cy.get('.oxd-topbar-header-breadcrumb').contains('Admin')

        cy.get("a[href*='/pim/viewPimModule']").click()  //PIM side option
        cy.url().should('include', 'pim/viewEmployeeList')
        cy.get('.oxd-topbar-header-breadcrumb').contains('PIM')

        cy.get("a[href*='/leave/viewLeaveModule']").click()  // Leave side option
        cy.url().should('include', 'leave/viewLeaveList')

        cy.get("a[href*='/time/viewTimeModule']").click()  // Time side option
        cy.url().should('include', 'time/viewEmployeeTimesheet')


        //  Verify user is able to close sidebar and viceversa
        cy.get("button[role='none']").click(2)

        //  Verify profile icon is showing
        cy.get("img[alt='profile picture']").should('be.visible')

        //   Verify when user click on profile icon other options are showing
        cy.get("img[alt='profile picture']").click()
        cy.get("a[href*='/auth/logout']").should('be.visible')

        // Verify when user click on profile icon other options are showing
        cy.get(':nth-child(1) > .oxd-userdropdown-link').should('be.visible')
        cy.get(':nth-child(2) > .oxd-userdropdown-link').should('be.visible')
        cy.get(':nth-child(3) > .oxd-userdropdown-link').should('be.visible')
        cy.get(':nth-child(4) > .oxd-userdropdown-link').should('be.visible')


        //   Verify user is able to logout

        cy.get("img[alt='profile picture']").click()
        cy.get("a[href*='/auth/logout']").click()


    })
})